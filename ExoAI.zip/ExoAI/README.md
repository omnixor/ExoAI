# 🌌 ExoAI — The AI Exoplanet Hunter  
**Discover worlds beyond our own using AI and NASA data.**

![NASA Banner](https://images-assets.nasa.gov/image/PIA23645/PIA23645~orig.jpg)

---

## 🚀 Overview
**ExoAI** is an AI-powered web application that analyzes NASA’s exoplanet data to identify and visualize potentially habitable worlds.

Using real datasets from the **NASA Exoplanet Archive** and a machine learning model, ExoAI predicts a *habitability score* for each planet and displays them in a stunning interactive 3D visualization.

> *"Somewhere, something incredible is waiting to be known." — Carl Sagan*

---

## 🌠 The Challenge
🧩 **NASA Space Apps Challenge 2025:**  
**“A World Away: Hunting for Exoplanets with AI”**

Thousands of exoplanets have been discovered — but which ones might be *Earth-like*?  
Scientists need intelligent tools that can make sense of massive datasets and highlight the most promising candidates for further study.

---

## 🎯 Goal
- Use **NASA’s open data** to predict which exoplanets could be habitable.  
- Create an **AI model** to generate a “habitability score.”  
- Visualize planets in a **3D interactive web interface.**  
- Make it open, free, and accessible to everyone.

---

## 🧠 How It Works

### 1. Data
Source: [NASA Exoplanet Archive — Confirmed Planets Table](https://exoplanetarchive.ipac.caltech.edu/)  
Fields used:
- Planet radius  
- Orbital period  
- Equilibrium temperature  
- Stellar mass  
- Distance from Earth  

### 2. AI Model
- Built with **Python + scikit-learn (RandomForestClassifier)**  
- Defines “habitable” planets as:
  - Temperature between 200K–350K  
  - Radius between 0.5×–2× Earth’s radius  
- Generates a **habitability probability (0–100)** for each planet.

### 3. Visualization
- Frontend built with **Streamlit + Plotly**  
- Displays planets on a **3D scatter plot**  
- Color-coded by habitability score  
- Includes a **“Top 10 Most Habitable Planets”** leaderboard

---

## ⚙️ Tech Stack

| Layer | Technology |
|-------|-------------|
| Data | NASA Exoplanet Archive (CSV / API) |
| ML Model | Python, scikit-learn |
| Notebook | Google Colab |
| Visualization | Streamlit, Plotly |
| Hosting | Streamlit Cloud (free) |
| Repo | GitHub |

---

## 🧭 System Architecture


---

## 🧪 Usage

### Option 1 — Run Locally
1. Clone the repo:
   ```bash
   git clone https://github.com/<your-username>/ExoAI.git
   cd ExoAI
pip install streamlit pandas plotly scikit-learn
streamlit run app.py
### Option 2 — Try it Online  
👉 **Live Demo:** [https://<your-streamlit-app>.streamlit.app](https://<your-streamlit-app>.streamlit.app)

---

## 📊 Output Example

| Planet Name | Habitability Score | Temperature (K) | Radius (Earths) |
|--------------|--------------------|-----------------|-----------------|
| Kepler-452b | 87.4 | 265 | 1.6 |
| TRAPPIST-1e | 82.1 | 243 | 0.9 |
| Kepler-62f | 77.6 | 289 | 1.4 |

---
---

## 💡 Future Improvements
- Integrate live NASA API updates  
- Use deep learning for better classification  
- Add explainability (“why is this planet rated this way?”)  
- Create VR/AR exploration mode  

---

## 🌍 Impact
ExoAI helps scientists, students, and space enthusiasts visualize the search for habitable exoplanets — turning raw NASA data into something **interactive, educational, and inspiring.**

---

## 🧑‍💻 Team
**Team Name:** [vibecoding404]  
**Members:** Jeevan (Developer, Cloud Secuirity Enthusiast)

---

## 📜 License
MIT License — free to use, modify, and share.  
NASA data is public domain.

---

### ⭐ If you like this project, star it on GitHub and help others discover new worlds!

